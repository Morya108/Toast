package nhr.toast;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button normal,customLocation,customSize,image,customImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initId();
    }

    private void initId() {
        normal=findViewById(R.id.normal_toast);
        customLocation=findViewById(R.id.custom_Location_toast);
        customSize=findViewById(R.id.custom_size_toast);
        image=findViewById(R.id.normal_image_toast);
        customImage=findViewById(R.id.custom_image_toast);

        normal.setOnClickListener(this);
        customLocation.setOnClickListener(this);
        customSize.setOnClickListener(this);
        image.setOnClickListener(this);
        customImage.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v==normal){
            Toast.makeText(getApplicationContext(),"normal_toast",Toast.LENGTH_SHORT).show();
        }
        if (v==customLocation){
            Toast toast = Toast.makeText(getApplicationContext(), "Custom Location Toast", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP, 100,100);
            toast.show();
        }
        if (v==customSize){
            Toast toast = Toast.makeText(getApplicationContext(), "Custom Size Toast", Toast.LENGTH_SHORT);
             ViewGroup group=(ViewGroup) toast.getView();
            TextView view1= (TextView) group.getChildAt(0);
            view1.setTextSize(30);
            toast.show();
        }
        if (v==image){
            Toast toast = Toast.makeText(getApplicationContext(), "Show Image In Toast", Toast.LENGTH_SHORT);
            LinearLayout toastContentView = (LinearLayout) toast.getView();
            ImageView imageView = new ImageView(getApplicationContext());
            imageView.setImageResource(R.drawable.toast);
            imageView.getPaddingTop();
            toastContentView.addView(imageView, 0);
            toast.show();
        }
        if (v==customImage){
            View toastView = getLayoutInflater().inflate(R.layout.image_toast, null);
            Toast toast = new Toast(getApplicationContext());
            toast.setView(toastView);
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER, 0,0);
            toast.show();
        }
    }
}
